import tkinter as tk
from tkinter import messagebox

NODE_WIDTH = 70
NODE_HEIGHT = 40
HORIZONTAL_GAP = 10
CANVAS_WIDTH = 520
CANVAS_HEIGHT = 220
START_X = 30
START_Y = 90


class QueueVisualizer:
    def __init__(self, root):
        self.root = root
        self.root.title("Queue Visualizer")

        self.queue = []

        self.canvas = tk.Canvas(root, width=CANVAS_WIDTH, height=CANVAS_HEIGHT, bg="white")
        self.canvas.pack(pady=20)

        control_frame = tk.Frame(root)
        control_frame.pack()

        tk.Label(control_frame, text="Push Value:").grid(row=0, column=0)
        self.push_entry = tk.Entry(control_frame, width=10)
        self.push_entry.grid(row=0, column=1)

        push_btn = tk.Button(control_frame, text="Push", command=self.push_value)
        push_btn.grid(row=0, column=2, padx=5)

        pop_btn = tk.Button(control_frame, text="Pop", command=self.pop_value)
        pop_btn.grid(row=1, column=2, pady=5)

        self.status_label = tk.Label(root, text="", fg="blue", font=("Arial", 12))
        self.status_label.pack(pady=5)

        self.draw_queue()

    def draw_node(self, x, y, data):
        self.canvas.create_rectangle(
            x, y, x + NODE_WIDTH, y + NODE_HEIGHT,
            fill="lightgreen", outline="black", width=2
        )
        self.canvas.create_text(
            x + NODE_WIDTH / 2,
            y + NODE_HEIGHT / 2,
            text=str(data),
            font=("Arial", 16)
        )

    def draw_queue(self):
        self.canvas.delete("all")

        if not self.queue:
            self.canvas.create_text(
                CANVAS_WIDTH / 2,
                CANVAS_HEIGHT / 2,
                text="Queue is empty",
                font=("Arial", 14),
                fill="gray"
            )
            return

        x = START_X
        y = START_Y

        for i, val in enumerate(self.queue):
            self.draw_node(x, y, val)

            # draw arrow between nodes
            if i < len(self.queue) - 1:
                arrow_start_x = x + NODE_WIDTH
                arrow_y = y + NODE_HEIGHT / 2
                self.canvas.create_line(
                    arrow_start_x,
                    arrow_y,
                    arrow_start_x + HORIZONTAL_GAP,
                    arrow_y,
                    arrow=tk.LAST,
                    width=2
                )
            x += NODE_WIDTH + HORIZONTAL_GAP + 10

        # Front label
        self.canvas.create_text(
            START_X + NODE_WIDTH / 2,
            START_Y - 25,
            text="Front",
            font=("Arial", 12),
            fill="red"
        )

        # Rear label
        rear_x = START_X + (len(self.queue) - 1) * (NODE_WIDTH + HORIZONTAL_GAP + 10) + NODE_WIDTH / 2
        self.canvas.create_text(
            rear_x,
            START_Y + NODE_HEIGHT + 20,
            text="Rear",
            font=("Arial", 12),
            fill="red"
        )

    def push_value(self):
        try:
            val = int(self.push_entry.get())
        except ValueError:
            messagebox.showerror("Invalid Input", "Please enter an integer value to push.")
            return

        self.queue.append(val)  # enqueue at rear
        self.push_entry.delete(0, tk.END)
        self.status_label.config(text=f"Pushed {val} into queue")
        self.draw_queue()

    def pop_value(self):
        if len(self.queue) == 0:
            messagebox.showinfo("Empty Queue", "Queue is empty. Cannot pop.")
            return

        val = self.queue.pop(0)  # dequeue from front
        self.status_label.config(text=f"Popped {val} from queue")
        self.draw_queue()


if __name__ == "__main__":
    root = tk.Tk()
    app = QueueVisualizer(root)
    root.mainloop()
