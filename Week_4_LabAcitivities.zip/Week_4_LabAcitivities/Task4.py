#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Mar 11 14:35:08 2026

@author: piao
"""
import timeit
import random

def linear_search(array, target):

    for i in range(len(array)):
        if array[i] == target:
            return i
        
    return -1

test = range(10)
print(linear_search(test, 99999))
print(linear_search(test, -999))


# BINARY SEARCH
# An alternative to linear search is binary search. Binary search can be more efficient than
# linear search, but with a few caveats.
# First, the algorithm is more complex (this tradeoff always exists), and second,
# it requires data to be sorted. If binary search is run on unsorted data, it
# can perform just as poorly as linear search and it may produce erroneous results.

def binary_search(array, target):

    # Initialize 'pointers'
    left = 0
    right = len(array) - 1 # Account for indexing to get the right most element index
    mid = int((left + right)/2)

    while left <= right:
        if array[mid] == target: # If target is found 
            return mid
        elif target > array[mid]:
            left = mid + 1 # We already checked the mid element, so we shift the index by 1 for the next search.
        elif target < array[mid]:
            right = mid - 1

        mid = int((left + right)/2) # Recalculate mid

    return -1

# SORTING ALGORITHMS
# Another major category of algorithm is the sorting algorithm. Sorting algorithms 
# are used to sort collections of elements into sorted order (such as numerical order for lists of numbers).


# BUBBLE SORT
def bubble_sort(arr):
    """
    Bubble Sort: A simple sorting algorithm that repeatedly steps through the list,
    compares adjacent elements, and swaps them if they are in the wrong order.

    Args:
    arr (list): The input list to be sorted.

    Returns:
    list: The sorted list in ascending order.
    """

    # Get the length of the input list
    n = len(arr)

    # Traverse through all elements in the list
    for i in range(n):

        # Flag to optimize the algorithm
        # If no swaps are performed in an iteration, the list is already sorted, and we can stop early
        swapped = False

        # Last i elements are already in place, so we don't need to compare them again
        for j in range(0, n - i - 1):

            # Compare adjacent elements
            if arr[j] > arr[j + 1]:

                # Swap if the element found is greater than the next element
                arr[j], arr[j + 1] = arr[j + 1], arr[j]

                # Set the swapped flag to True to indicate that a swap occurred in this iteration
                swapped = True

        # If no two elements were swapped in the inner loop, the list is sorted, and we can exit early
        if not swapped:
            break

    return arr

# Example usage:
unsorted_list = [11, 12, 22, 25, 64]
sorted_list = bubble_sort(unsorted_list)
print("Sorted array:", sorted_list)



# INSERTION SORT
def insertion_sort(arr):
    """
    Insertion Sort: A simple sorting algorithm that builds the final sorted
    array one item at a time. It takes each element from the input list and
    inserts it into its correct position in the sorted part of the array.

    Args:
    arr (list): The input list to be sorted.

    Returns:
    list: The sorted list in ascending order.
    """

    # Traverse through all elements in the list, starting from the second element (index 1)
    for i in range(1, len(arr)):

        # Store the current element to be compared and inserted into the sorted part of the list
        current_element = arr[i]

        # Move elements of the sorted part of the list that are greater than the current element
        # to one position ahead of their current position
        j = i - 1
        while j >= 0 and current_element < arr[j]:
            arr[j + 1] = arr[j]
            j -= 1

        # Insert the current element into its correct position in the sorted part of the list
        arr[j + 1] = current_element

    return arr



# Challenge solution
def binary_search_insertion(array, target):
    array = insertion_sort(array.copy())
    result = binary_search(array, target)
    return result

def binary_search_bubble(array, target):
    array = bubble_sort(array.copy())
    result = binary_search(array, target)
    return result

def linear_search_insertion(array, target):
    array = insertion_sort(array.copy())
    result = linear_search(array, target)
    return result

def linear_search_bubble(array, target):
    array = bubble_sort(array.copy())
    result = linear_search(array, target)
    return result

for data_size in [10, 1000, 10000]:
    unsorted_list = [random.randint(1, 1000) for n in range(data_size)]
    target = random.randint(1, 1000)

    binary_time_insertion = timeit.timeit(lambda: binary_search_insertion(unsorted_list, target), number=1)
    binary_time_bubble = timeit.timeit(lambda: binary_search_bubble(unsorted_list, target), number=1)
    linear_time_insertion = timeit.timeit(lambda: linear_search_insertion(unsorted_list, target), number=1)
    linear_time_bubble = timeit.timeit(lambda: linear_search_bubble(unsorted_list, target), number=1)
    linear_time = timeit.timeit(lambda: linear_search(unsorted_list, target), number=1)


    print(f"\nData size: {data_size}")
    print(f"Insertion Sort + Binary Search: {binary_time_insertion:.6f} seconds")
    print(f"Bubble Sort + Binary Search:    {binary_time_bubble:.6f} seconds")
    print(f"Insertion Sort + Linear Search: {linear_time_insertion:.6f} seconds")
    print(f"Bubble Sort + Linear Search:    {linear_time_bubble:.6f} seconds")
    print(f"Linear Search only (unsorted):  {linear_time:.6f} seconds")


# One takeaway here is that the most efficient
# algorithm on paper isn't always the most 
# efficient in practice. If binary search requires
# sorted data, and we only have unsorted data,
# then we'll need to factor in the efficiency
# of the sorting algorithm as well when choosing
# a searching algorithm. In this case, linear search
# might win out simply because you don't need to 
# sort the list before searching.