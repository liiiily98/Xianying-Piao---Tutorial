#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Mar 11 16:33:24 2026

@author: piao
"""

import timeit
import random

# Now that we've gotten some background on searching algorithms, let's
# try and implement some basic ones. First, we'll try the most basic of all:
# linear search. Despite its simplicity, linear search is actually the
# algorithm that Python lists use when we check membership with the 'in'
# keyword.
#
# Note that with the Python data structures we're using here, the function
# of these algorithms is not necessary (as the Python structures already
# implement searching, sorting, etc.). We are doing it for the sake of 
# learning the theory. In practice, it is recommended to use the
# built in searching functions!


# LINEAR SEARCH
# To review, linear search involves sequentially checking every element
# in a collection until the desired value is found.
def linear_search(array, target):

    for i in range(len(array)):
        if array[i] == target:
            return i
        
    return -1

test = range(1000000)
print(linear_search(test, 99999))
print(linear_search(test, -999))


# BINARY SEARCH
# An alternative to linear search is binary search. Binary search can be more efficient than
# linear search, but with a few caveats.
# First, the algorithm is more complex (this tradeoff always exists), and second,
# it requires data to be sorted. If binary search is run on unsorted data, it
# can perform just as poorly as linear search and it may produce erroneous results.

def binary_search(array, target):

    # Initialize 'pointers'
    left = 0
    right = len(array) - 1 # Account for indexing to get the right most element index
    mid = int((left + right)/2)

    while left <= right:
        if array[mid] == target: # If target is found 
            return mid
        elif target > array[mid]:
            left = mid + 1 # We already checked the mid element, so we shift the index by 1 for the next search.
        elif target < array[mid]:
            right = mid - 1

        mid = int((left + right)/2) # Recalculate mid

    return -1


test = [1, 1, 1, 2, 3, 6, 9, 19, 555]
print(binary_search(test, 1))
print(binary_search(test, 555))

# Note another quirk of binary search is that it does not guarantee to return
# the first occurance of an element, just *some* occurance if that element does in fact appear.

# Comparing linear and binary search efficiency
# Generate a sorted list of integers for testing
for data_size in [10, 50000, 1000000]:
    sorted_list = list(range(data_size))

# Test cases
    target = random.randint(0, data_size - 1)  # Random target value
    linear_time = timeit.timeit(lambda: linear_search(sorted_list, target), number=100)
    binary_time = timeit.timeit(lambda: binary_search(sorted_list, target), number=100)

    print(f"Linear search execution time: {linear_time:.6f} seconds")
    print(f"Binary search execution time: {binary_time:.6f} seconds")
    