#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Mar 18 09:37:12 2026

@author: piao
"""

import timeit


# RECURSION
# At its core, recursion involves solving a problem 
# by breaking it down into smaller, more manageable instances of the same problem. 

# BASIC RECURSION EXAMPLE
def sum_of_natural_numbers(n):
    if n == 1:
        return 1 # Base case
    else:
        return n + sum_of_natural_numbers(n - 1) # Recursive case

def sum_of_natural_numbers_iterative(n):
    total = 0
    while n > 0:
        total += n
        n -= 1
    return total

# Example usage:
for n in [10, 50, 100, 500]:
    result = sum_of_natural_numbers(n)  
    print(f"The sum of the first {n} natural numbers is {result}")
    result_iter = sum_of_natural_numbers_iterative(n)
    print(f"The sum of the first {n} natural numbers (iterative) is {result_iter}")


    t_rec  = timeit.timeit(lambda: sum_of_natural_numbers(n), number=1000)
    t_iter = timeit.timeit(lambda: sum_of_natural_numbers_iterative(n), number=1000)
    print(f"Recursive: {t_rec:.6f}s | Iterative: {t_iter:.6f}s")

# RECURSIVELY CALCULATING FIBONACCI SEQUENCE (more difficult example)
# f(n) = f(n - 1) + f(n - 2)
def fibonacci(n):
    if n <= 0:
        return 0 # Base case
    elif n == 1:
        return 1 # Base case 
    else:
        return fibonacci(n - 1) + fibonacci(n - 2) # Recursive case

def fibonacci_iterative(n):
    if n <= 0:
        return 0
    elif n == 1:
        return 1
    a, b = 0, 1
    for _ in range(2, n + 1):
        a, b = b, a + b
    return b

# Example usage:
for n in [10, 20, 25, 30]:
    result = fibonacci(n)  
    print(f"The {n}th Fibonacci number is {result}")
    result_iter = fibonacci_iterative(n)
    print(f"The {n}th Fibonacci number (iterative) is {result_iter}")


    t_rec  = timeit.timeit(lambda: fibonacci(n), number=100)
    t_iter = timeit.timeit(lambda: fibonacci_iterative(n), number=100)
    print(f"Recursive: {t_rec:.6f}s | Iterative: {t_iter:.6f}s")



# CHALLENGE: Use recursion to calculate the factorial.
def factorial(n):
    """
    Recursive function to calculate the factorial of a non-negative integer.

    Args:
    n (int): Non-negative integer for which factorial is calculated.

    Returns:
    int: Factorial of the input integer.
    """
    if n == 0:
        return 1  # Base case: factorial of 0 is 1
    else:
        return n * factorial(n - 1)  # Recursive case: n! = n * (n-1)!
    
def factorial_iterative(n):
    result = 1
    for i in range(2, n + 1):
        result *= i
    return result
   
# Example usage:
for n in [10, 50, 100]:
    result = factorial(n)
    print(f"The factorial of {n} is {result}")

    result_iter = factorial_iterative(n)
    print(f"The factorial of {n} (iterative) is {result_iter}")


    t_rec  = timeit.timeit(lambda: factorial(n), number=1000)
    t_iter = timeit.timeit(lambda: factorial_iterative(n), number=1000)
    print(f"Recursive: {t_rec:.6f}s | Iterative: {t_iter:.6f}s")