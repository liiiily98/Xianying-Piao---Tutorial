#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Mar 18 13:15:56 2026

@author: piao
"""

from tkinter import *
import math

class KochSnowflake:
    def __init__(self):
        window = Tk()
        window.title("Koch Snowflake")
        
        self.width = 400
        self.height = 400
        self.canvas = Canvas(window, width=self.width, height=self.height)
        self.canvas.pack()
        
        frame1 = Frame(window)
        frame1.pack()
        
        Label(frame1, text="Enter an order: ").pack(side=LEFT)
        self.order = StringVar()
        Entry(frame1, textvariable=self.order, justify=RIGHT).pack(side=LEFT)
        Button(frame1, text="Display Koch Snowflake",
               command=self.display).pack(side=LEFT)
        
        window.mainloop()
    
    def display(self):
        self.canvas.delete("line")
        size = 300
        # Three sides of equilateral triangle
        p1 = [self.width/2 - size/2, self.height/2 + size/3]
        p2 = [self.width/2 + size/2, self.height/2 + size/3]
        p3 = [self.width/2, self.height/2 - size*2/3]
        
        order = int(self.order.get())
        self.drawKoch(order, p1, p2)
        self.drawKoch(order, p2, p3)
        self.drawKoch(order, p3, p1)
    
    def drawKoch(self, order, p1, p2):
        if order == 0:
            self.canvas.create_line(p1[0], p1[1], p2[0], p2[1], tags="line")
        else:
            # Divide line into 3 equal parts
            pA = [p1[0] + (p2[0]-p1[0])/3, p1[1] + (p2[1]-p1[1])/3]
            pB = [p1[0] + (p2[0]-p1[0])*2/3, p1[1] + (p2[1]-p1[1])*2/3]
            
            # Calculate the peak of outward triangle
            angle = math.pi / 3
            dx = pB[0] - pA[0]
            dy = pB[1] - pA[1]
            pC = [pA[0] + dx*math.cos(angle) - dy*math.sin(angle),
                  pA[1] + dx*math.sin(angle) + dy*math.cos(angle)]
            
            self.drawKoch(order-1, p1, pA)
            self.drawKoch(order-1, pA, pC)
            self.drawKoch(order-1, pC, pB)
            self.drawKoch(order-1, pB, p2)

KochSnowflake()