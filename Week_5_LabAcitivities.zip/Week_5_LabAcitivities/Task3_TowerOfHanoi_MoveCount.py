#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Mar 18 15:36:48 2026

@author: piao
"""

move_count = 0

def main():
    global move_count
    move_count = 0
    n = eval(input("Enter number of disks: "))
    print("The moves are:")
    moveDisks(n, 'A', 'B', 'C')
    print("Number of moves is", move_count)

def moveDisks(n, fromTower, toTower, auxTower):
    global move_count
    if n == 1:
        print("Move disk", n, "from", fromTower, "to", toTower)
        move_count += 1
    else:
        moveDisks(n - 1, fromTower, auxTower, toTower)
        print("Move disk", n, "from", fromTower, "to", toTower)
        move_count += 1
        moveDisks(n - 1, auxTower, toTower, fromTower)

main()